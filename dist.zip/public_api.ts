export * from './src/app/mc-login/mc-login.module';
export * from './src/app/mc-signup/mc-signup.module';
export * from './src/app/mc-consent/mc-consent.module';
export * from './src/app/mc-profile/mc-profile.module';
export * from './src/app/mc-widget-root/mc-widget-root.module';